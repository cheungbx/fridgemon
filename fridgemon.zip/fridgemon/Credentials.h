/*

 Save your Credentials in a secret file so it will not accidentially reviewed with your source code.
 your Credentials.h file should be in the same folder as your source code for the arduino project and have the following content:
 I am useing adafruit.io as the MQTT broker and dashboard service. You can use other MQTT services on the internet.


#define WIFIssid             "YourWIFISSID" // home wifi SSID
#define WIFIpassword         "YourWIFIPassword" // home wifi Password


// copy these two lines from adafruit.io  viewAIOKey screen.
 #define IO_USERNAME      "?????????"
 #define IO_KEY           "????????????????????????????????"

 #define MQTT_AirTemp      "temp1"
 #define MQTT_Humidity     "humid1"
*/


#define  WIFIssid        "YourWIFISSID"
#define  WIFIpassword    "YourWIFIPassword"

// copy these two lines from adafruit.io  viewAIOKey screen.
#define IO_USERNAME      "?????????"
#define IO_KEY           "????????????????????????????????"

 #define MQTT_AirTemp      "temp1"
 #define MQTT_Humidity     "humid1"


#define MQTT_SERVER          "io.adafruit.com"
#define MQTT_SERVERPORT      1883
