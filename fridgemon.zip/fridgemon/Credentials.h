/*

 Save your Credentials in a secret file so it will not accidentially reviewed with your source code.
 your Credentials.h file should be in the same folder as your source code for the arduino project and have the following content:
 I am useing adafruit.io as the MQTT broker and dashboard service. You can use other MQTT services on the internet.


#define WIFIssid             "YourWIFISSID" // home wifi SSID
#define WIFIpassword         "YourWIFIPassword" // home wifi Password


// copy these two lines from adafruit.io  viewAIOKey screen.
 #define IO_USERNAME      "?????????"
 #define IO_KEY           "????????????????????????????????"
 
 #define MQTT_AirTemp      "temp1"
 #define MQTT_Humidity     "humid1"
*/


#define WIFIssid             "YourWIFISSID" // home wifi SSID
#define WIFIpassword         "YourWIFIPassword" // home wifi Password


// account 1
 #define IO_USERNAME      "miclaiwk"
 #define IO_KEY           "a9f41bb949fe4cd3b72b238d99b95d13"
 #define MQTT_AirTemp      "temp3"
 #define MQTT_Humidity     "humid3"



/*
// account 2
#define IO_USERNAME       "miclaiwi"
#define IO_KEY            "504edbc469b144fc86b2a408564aa9f5"
#define MQTT_AirTemp      "temp2"
#define MQTT_Humidity     "humid2"

*/

#define MQTT_SERVER          "io.adafruit.com"    
#define MQTT_SERVERPORT      1883
